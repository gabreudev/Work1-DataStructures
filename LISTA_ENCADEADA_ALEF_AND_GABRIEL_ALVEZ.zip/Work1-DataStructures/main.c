#include <stdio.h>
#include "image.h"
// #include "raylib.h"
// #include <stdlib.h>
// #include <string.h>
// #include "image.c"
// #include <Python.h>

int main(void)
{
    init();
    return 0;
}

